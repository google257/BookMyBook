package com.app.custom_exceptions;
@SuppressWarnings("serial")
public class CustomException extends RuntimeException {

	public CustomException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}